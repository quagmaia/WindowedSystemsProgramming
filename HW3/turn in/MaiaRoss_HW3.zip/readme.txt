Maia Ross

javac Start.java
java Start

Note that I included the grad student parts for EC!
@FunctionalInterface
public interface BasicHandler {
	public void handle(String string);
}
